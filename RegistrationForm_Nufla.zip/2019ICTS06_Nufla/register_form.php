<?php
@include 'config.php';

if(isset($_POST['submit'])) {
    $fname = mysqli_real_escape_string($conn,$_POST['fname']);
    $lname = mysqli_real_escape_string($conn,$_POST['lname']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $pass = mysqli_real_escape_string($conn,$_POST['password']);
    $cpass = mysqli_real_escape_string($conn,$_POST['cpassword']);
    $user_type = mysqli_real_escape_string($conn,$_POST['user_type']);
    $add = mysqli_real_escape_string($conn,$_POST['address']);
    $user_gender = mysqli_real_escape_string($_POST['user_gender']);
    $uni = mysqli_real_escape_string($conn,$_POST['university']);
    $phone = mysqli_real_escape_string($conn,$_POST['phoneNO']);
    $w_title = mysqli_real_escape_string($conn,$_POST['webinar_title']);
    $w_date = mysqli_real_escape_string($conn,$_POST['webDate']);
    $w_duration= mysqli_real_escape_string($conn,$_POST['webinar_duration']);
    $reg_date = mysqli_real_escape_string($conn,$_POST['regDate']);
    $payment_date = mysqli_real_escape_string($conn,$_POST['paymentDate']);
    $payment_method = mysqli_real_escape_string($conn,$_POST['payment_method']);
    $district = mysqli_real_escape_string($conn,$_POST['district']);

    $select = " SELECT * FROM user_form WHERE email= '$email' && password = '$pass' ";

    $result = mysqli_query($conn, $select);
    
    if(mysqli_num_rows($result) > 0){
        $error[]= 'user already exit!';
    }
    else {
        if($pass != $cpass){
            $error[]= 'password not matched!';
        }
        else {
            $insert = " INSERT INTO user_form( fname, lname, email, password, user_type, address, user_gender, university, phoneNO,	webinar_title, webDate, webinar_duration, regDate, paymentDate, payment_method, district)
            VALUES('$fname','$lname', '$email', '$pass','$user_type','$add','$user_gender','$uni','$phone','$w_title','$w_date','$w_duration','$reg_date','$payment_date','$payment_method','$district')";
            mysqli_query($conn, $insert);
            header('location:login_form.php');
        }
    }
};
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<div class="form-container">

   <form action="" method="post">
      <h3>Webinar Registration Form</h3>
      <?php
      if(isset($error)){
         foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         };
      };
      ?>
      <input type="text" name="fname" required placeholder="enter your first name">
      <input type="text" name="lname" required placeholder="enter your last name">
      <input type="email" name="email" required placeholder="enter your email">
      <input type="password" name="password" required placeholder="enter your password">
      <input type="password" name="cpassword" required placeholder="enter your confirm password">
      <select name="user_type">
         <option value="user">user</option>
         <option value="admin">admin</option>
      </select>
      <input type="address" name="address" required placeholder="enter your address">
       <select name="user_gender">
         <option value="male" >Male</option>
         <option value="female" >Female</option>
         <option value="other">Other</option>
      </select>
       <input type="university" name="university" required placeholder="enter your university">
        <input type="phoneNO" name="phoneNO" required placeholder="enter your PhoneNo"> 
        
        <select name="webinar_title">
         <option value="Cyberbullying">Cyberbullying</option>
         <option value="Web Design tips to increase conversions">Web Design tips to increase conversions</option>
         <option value="eveloping a framework">Developing a framework</option>
      </select>
      <input type="date" name="webDate" required placeholder="enter your webinar date"> 
      <select name="webinar_duration">
         <option value="One hour">One hour</option>
         <option value="Two hours">Two hours</option>
         <option value="hree hours">Three hours</option>
      </select>
      <input type="date" name="regDate" required placeholder="enter your Registration date"> 
      <input type="date" name="paymentDate" required placeholder="enter your Payment date"> 
        
       <select name="payment_method">
         <option value="cash">Cash</option>
         <option value="card">Card</option>
      </select>
      <select name="district">
         <option value="ampara">Ampara</option>
         <option value="NuweraEliye">Nuwera Eliye</option>
         <option value="jaffna">Jaffna</option>
         <option value="vanni">Vavuniya</option>
         <option value="Kekol">Kekala</option>
         <option value="Kurunagala">Kurunagala</option>
         <option value="colombo">Colombo</option>
      </select>
       <div class="buttons">
      <input type="submit" name="submit" value="Display" class="form-btn">
      <input type="submit" name="submit" value="Submit" class="form-btn">
      <input type="submit" name="submit" value="Reset" class="form-btn">
      </div>
      <p>already have an account? <a href="login_form.php">login now</a></p>
   </form>

</div>

</body>
</html>